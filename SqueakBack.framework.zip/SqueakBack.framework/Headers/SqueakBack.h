//
//  SqueakBack.h
//  SqueakBack
//
//  Created by Ray Fix on 7/28/15.
//  Copyright (c) 2015 Pelfunc, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SqueakBack.
FOUNDATION_EXPORT double SqueakBackVersionNumber;

//! Project version string for SqueakBack.
FOUNDATION_EXPORT const unsigned char SqueakBackVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SqueakBack/PublicHeader.h>
#import <SqueakBack/SqueakBackActivator.h>

