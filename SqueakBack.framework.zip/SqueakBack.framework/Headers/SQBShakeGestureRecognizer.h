//
//  SQBShakeGestureRecognizer.h
//  SqueakBack
//
//  Created by Ray Fix on 10/14/15.
//  Copyright © 2015 Pelfunc, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQBShakeGestureRecognizer : UIGestureRecognizer

@end
