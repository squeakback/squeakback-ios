To prepare for release:

0. Set target to be SqueakBack, iPhone 5 simulator
1. Edit Scheme for SqueakBack Command-<
2. For SqueakBack Scheme, Run Mode, set build configuration to Release
3. Do a "super clean" Shift-Option-Command-K
4. Click the Run button (This will not launch the sim)
5. Open Build logs and type Search "SANJAY" to reveal the build path
6. Open Build path in finder  Copy SqueakBack.framework to desktop



